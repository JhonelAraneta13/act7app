package com.example.activity7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class REVIEWS_ACTIVITY extends AppCompatActivity {

    private TextView postInfo;
    private RequestQueue myQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reviews);

        //Retrieved Json Data
        postInfo = findViewById(R.id.textView_read);

        //adding a scroll feature in case the data fills the textview
        postInfo.setMovementMethod(new ScrollingMovementMethod());

        //for the request queue using volley
        myQueue = Volley.newRequestQueue(this);

        Button btn = (Button)findViewById(R.id.button3);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(REVIEWS_ACTIVITY.this, MainActivity.class));
            }
        });
    }

    //method fo calling INSERT_ACTIVITY
    public void insert_window(View view) {
        getRequest();
    }



    private void getRequest(){

        String url = "https://multiparous-movemen.000webhostapp.com/index.php"; //api endpoint

        //json request using GET
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            //the root object inside the json data is users
                            //browse the api endpoint to check the root object
                            //users is an JSONArray
                            JSONArray jsonArray = response.getJSONArray("rela_details"); //your table

                            //loop the json array according to its length
                            //assign and append data every loop
                            for(int  i = 0; i < jsonArray.length(); i++){
                                JSONObject users = jsonArray.getJSONObject(i);
                                //variables
                                String myID = users.getString("rela_number");
                                String myName =Integer.toString(users.getInt("rela_number"));
                                String myEmail = users.getString("rela_color");
                                String myPost = Integer.toString(users.getInt("ratings"));
                                String remarks = users.getString("remarks");
                                String reviews = users.getString("reviews");

                                postInfo.append(
                                        "Rela_number: "+myName+"\n"+
                                                "Color: "+myEmail+"\n"+
                                                "Ratings: "+myPost+"\n"+
                                                "Remarks: "+remarks+"\n"+
                                                "Reviews:"+reviews+"\n\n"
                                );
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        //add the request queue
        myQueue.add(request);

    }
}