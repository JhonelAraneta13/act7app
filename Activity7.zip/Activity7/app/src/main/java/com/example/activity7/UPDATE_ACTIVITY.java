package com.example.activity7;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UPDATE_ACTIVITY extends AppCompatActivity {

    private EditText idTXT;
    private EditText nameTXT;
    private EditText emailTXT;
    private EditText postTXT;
    private RequestQueue myQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        idTXT = findViewById(R.id.update_id_search);
        nameTXT = findViewById(R.id.update_name);
        emailTXT = findViewById(R.id.update_email);
        postTXT = findViewById(R.id.update_post);
        myQueue = Volley.newRequestQueue(this);
    }

    public void up_data_search(View v){
        search_id();
    }
    public void up_data_update(View v){
        update_data();
    }
    public void backMenu(View v){

        Intent myIntent = new Intent(UPDATE_ACTIVITY.this, MainActivity.class);
        UPDATE_ACTIVITY.this.startActivity(myIntent);
    }
    //same method used in the main activity but get retrieves only on row
    private void search_id(){
        String myID = idTXT.getText().toString().trim();
        String url = "https://multiparous-movemen.000webhostapp.com/index.php";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        int i; //declared outside the loop go its global inside this method
                        try {

                            JSONArray jsonArray = response.getJSONArray("rela_details");
                            //loop throughout the array
                            for(i = 0; i < jsonArray.length(); i++) {

                                JSONObject users = jsonArray.getJSONObject(i);
                                String myId = users.getString("rela_number");
                                //if the id inside an array element matched the inputted id break the loop
                                if(myId.equals(myID)){
                                    break;
                                }

                            }
                            //assign the values afterwards using the current array position(i)
                            JSONObject users = jsonArray.getJSONObject(i);
                            String myName =Integer.toString(users.getInt("rela_number"));
                            String myEmail = users.getString("rela_color");
                            String myPost = Integer.toString(users.getInt("ratings"));
                            String remarks = users.getString("remarks");

                            nameTXT.setText(myEmail);
                            emailTXT.setText(myPost);
                            //postTXT.setText(myPost);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        myQueue.add(request);

    }

    private void update_data(){
        //trimmed input data
        final String name = nameTXT.getText().toString().trim();
        final String email = emailTXT.getText().toString().trim();
        final String post = ", " + postTXT.getText().toString().trim();
        final String id = idTXT.getText().toString().trim();


        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Updating....");
        progressDialog.show();
        //post api request on update data
        StringRequest request_new = new StringRequest(Request.Method.POST, "https://multiparous-movemen.000webhostapp.com/update_data.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //if the request is successful, close this activity
                        Toast.makeText(UPDATE_ACTIVITY.this, response, Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        finish();
                        progressDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(UPDATE_ACTIVITY.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();

            }
        }){

            //params to be pass on the php request
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params = new HashMap<String,String>();
                //pass variables to url parameters
                params.put("var1",id);
                params.put("var2",post);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(UPDATE_ACTIVITY.this);
        requestQueue.add(request_new);
    }

}
